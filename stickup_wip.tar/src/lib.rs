//stickip/src/lib.rs

#![cfg_attr(docsrs, feature(doc_cfg))]

pub mod backends;
pub mod binding;
pub mod device;
pub mod event;

pub mod metadata;
pub mod snapshot;

// ---- Re-exports (convenience) ----

pub use binding::*;
pub use event::*;
pub use snapshot::Snapshot;

// Optional: ergonomic import bundle for app crates.
pub mod prelude {
    // Bindings & transforms
    pub use crate::binding::{
        AxisCurve, AxisTransform, BindingOutput, BindingProfile, BindingRule, ControlPath,
        ControlPath2D, ControlType, DeviceState,
    };

    // Core device trait & manager
    pub use crate::device::Device;

    // Events & event bus
    pub use crate::event::InputKind;

    // Metadata & snapshots
    pub use crate::metadata::DeviceMeta;
    pub use crate::snapshot::Snapshot;
}
