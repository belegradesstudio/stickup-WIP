//! Input backends for `stickup`.
//!
//! Implementations of [`Device`](crate::device::Device) for real hardware (HID)
//! and software-emulated (virtual) devices.
//!
//! # Feature flags
//! - **`hid`** — enables the HID backend (default).
//! - **`virtual`** — enables the virtual device backend (default).
//!
//! # Re-exports
//! For convenience this module re-exports:
//! - [`probe_devices`] — enumerate HID devices (requires `hid`).
//! - [`create_virtual_devices`] — create one default virtual device (requires `virtual`).

#[cfg(feature = "hid")]
#[cfg_attr(docsrs, doc(cfg(feature = "hid")))]
pub mod windows;
